import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9d52b423-cdfb-4e98-a885-f928f4757e42")
public class Roi extends Piece {
    @objid ("0216b588-61ad-4877-b7ed-f735591654f9")
    private boolean aBouge;

    @objid ("27539108-b324-4fa1-8032-9bb59b61dd40")
    public boolean isABouge() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.aBouge;
    }

    @objid ("c178a819-5fa1-4176-8eb4-6392ff32603c")
    public void setABouge(boolean value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.aBouge = value;
    }
    
    public void mouvement(int x, int y){
    
    }

}
