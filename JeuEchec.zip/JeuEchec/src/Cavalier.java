import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4510cf59-2364-4a43-82fe-df47eb3f266c")
public class Cavalier extends Piece {

    public void mouvement(int x, int y){
    
    }

}
