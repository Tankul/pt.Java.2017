import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9c9fda66-2952-4485-9a7d-ac10b1a54201")
public abstract class Piece {
    @objid ("d42e0f91-af13-46ae-b893-e13a3d2c3ea2")
    private int x;

    @objid ("10a3267a-4907-44b2-b0a0-b92b0f88b367")
    private int y;

    @objid ("e3a61fd0-b042-4ee5-b29e-a8050ab2021b")
    private boolean couleur;

    @objid ("71a23c43-bd6b-4f14-bb35-ae389f2df766")
    public void setX(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.x = value;
    }

    @objid ("a0432975-9edf-47bc-a97e-47258816dedc")
    public int getX() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.x;
    }

    @objid ("fac75421-83e1-418d-9d7a-7b6451fdd46c")
    public int getY() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.y;
    }

    @objid ("151d2b58-77c5-440a-87aa-946f9dda7245")
    public void setY(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.y = value;
    }

    @objid ("e8f0bef3-f992-454f-9c6c-6e45526fc85d")
    public boolean isCouleur() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.couleur;
    }

    @objid ("2f001ea4-c222-40be-abb3-36a47602e540")
    public void setCouleur(boolean value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.couleur = value;
    }

    @objid ("83599e98-9a97-43e2-8c73-3051a160af22")
    public void mouvement(int x, int y) {
    }

}
