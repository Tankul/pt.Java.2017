import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5de5206c-feea-4fa0-8f67-5c12fb2db793")
public class Fou extends Piece {
    public void mouvement(int x, int y){
    
    }
}
