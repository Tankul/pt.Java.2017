import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("af47bae8-5d4c-43e7-9a0a-356373844e6c")
public class Reine extends Piece {
    public void mouvement(int x, int y){
    
    }
}
