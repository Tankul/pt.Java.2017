import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5c857c9e-0f4f-4873-ac31-c7d6f9a1c5e5")
public class Pion extends Piece {
    @objid ("6c09b812-81b9-42b4-add0-138f92c593ab")
    private boolean aBouge;

    @objid ("4bcb230e-a377-41cb-a7d6-7861f5a7ddbf")
    public boolean isABouge() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.aBouge;
    }

    @objid ("36ea9a11-a8ee-49d3-b8a1-8b6eb72c7b89")
    public void setABouge(boolean value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.aBouge = value;
    }
    
    public void mouvement(int x, int y){
    
    }

}
