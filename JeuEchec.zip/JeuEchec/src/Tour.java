import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("177e087b-4e83-4bed-80c6-a6fcdcbedd1a")
public class Tour extends Piece {
    @objid ("c6c9d435-2633-4a9c-92c1-00a9fb5d36ca")
    private boolean aBouge;

    @objid ("a16ecf74-7c3b-435a-a9d6-97b43134592f")
    public boolean isABouge() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.aBouge;
    }

    @objid ("bcba6adb-3a16-4f6e-955f-2757ebd55027")
    public void setABouge(boolean value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.aBouge = value;
    }
    
    public void mouvement(int x, int y){
    
    }

}
